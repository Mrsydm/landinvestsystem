const express = require('express');
const router = express.Router();
const Land = require('../models/Land');

router.get('/', async (req, res) => {
  const land = await Land.find().populate('uploaded_by');
  res.json(land);
});

router.post('/', async (req, res) => {
  const newLand = new Land(req.body);
  await newLand.save();
  res.status(201).json(newLand);
});

module.exports = router;
