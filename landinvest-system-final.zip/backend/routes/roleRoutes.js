const express = require('express');
const router = express.Router();
const Role = require('../models/Role');

router.get('/', async (req, res) => {
  const roles = await Role.find();
  res.json(roles);
});

router.post('/', async (req, res) => {
  const newRole = new Role(req.body);
  await newRole.save();
  res.status(201).json(newRole);
});

module.exports = router;
