const mongoose = require('mongoose');

const landSchema = new mongoose.Schema({
  title: String,
  location: String,
  price: Number,
  description: String,
  uploaded_by: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  offers: [
    {
      buyer_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      amount: Number,
      accepted: { type: Boolean, default: false }
    }
  ],
  documents: [String]
});

module.exports = mongoose.model('Land', landSchema);
