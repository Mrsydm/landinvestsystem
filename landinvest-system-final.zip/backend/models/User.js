const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  full_name: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: mongoose.Schema.Types.ObjectId, ref: 'Role' },
  preferences: {
    location: [String],
    max_price: Number
  }
});

module.exports = mongoose.model('User', userSchema);
