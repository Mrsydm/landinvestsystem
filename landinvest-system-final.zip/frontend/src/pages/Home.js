import React from 'react';

const Home = () => {
  return <div>Welcome to the LandInvest Dashboard</div>;
};

export default Home;
