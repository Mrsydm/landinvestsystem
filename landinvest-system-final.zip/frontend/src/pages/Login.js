import React from 'react';

const Login = () => {
  return <div>Login Page</div>;
};

export default Login;
